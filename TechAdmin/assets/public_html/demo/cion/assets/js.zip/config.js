var primary = localStorage.getItem("cion_primary") || '#35bfbf';
var secondary = localStorage.getItem("cion_secondary") || '#FF6150';

window.CionAdminConfig = {
	// Theme Primary Color
	primary: primary,
	// theme secondary color
	secondary: secondary,
};
